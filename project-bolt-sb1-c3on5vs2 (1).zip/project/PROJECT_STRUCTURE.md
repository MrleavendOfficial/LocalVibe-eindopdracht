# LocalVibe - Project Structure

## 📁 Directory Overview

```
localvibe/
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── auth/           # Authentication components
│   │   ├── chat/           # Chat/messaging components
│   │   ├── events/         # Event management components
│   │   ├── feed/           # Social feed components
│   │   └── layout/         # Layout components (nav, header, etc.)
│   │
│   ├── pages/              # Full page components (routes)
│   │   ├── AuthPage.tsx    # Login/Signup page
│   │   ├── FeedPage.tsx    # Main feed page
│   │   ├── ChatPage.tsx    # Chat/messaging page
│   │   ├── EventsPage.tsx  # Events listing page
│   │   └── ProfilePage.tsx # User profile page
│   │
│   ├── lib/                # External service integrations
│   │   └── supabase.ts     # Supabase client configuration
│   │
│   ├── store/              # Global state management
│   │   └── authStore.ts    # Authentication state (Zustand)
│   │
│   ├── types/              # TypeScript type definitions
│   │   └── database.ts     # Database schema types
│   │
│   ├── App.tsx             # Main app component
│   ├── main.tsx            # App entry point
│   └── index.css           # Global styles (Tailwind)
│
├── public/                 # Static assets
├── dist/                   # Production build output
│
├── .env                    # Environment variables (Supabase keys)
├── vite.config.ts          # Vite configuration + PWA setup
├── tailwind.config.js      # Tailwind CSS configuration
├── tsconfig.json           # TypeScript configuration
├── package.json            # Dependencies & scripts
│
├── README.md               # Full documentation
├── SETUP.md                # Setup instructions
├── QUICKSTART.md           # Quick reference
└── PROJECT_STRUCTURE.md    # This file
```

## 🗂️ Component Architecture

### Auth Flow
```
AuthPage
├── LoginForm        # Email/password login
└── SignupForm       # Registration with age check
    ↓
AuthProvider         # Session management
    ↓
App (protected routes)
```

### Feed System
```
FeedPage
├── CreatePost       # Post creation with image upload
│   └── Supabase Storage API
└── PostCard[]       # Post display with likes
    ├── Like button (real-time counter)
    └── Delete button (own posts only)
```

### Chat System
```
ChatPage
├── ChannelList      # Sidebar with channels
│   └── Channel creation modal
└── Chat Area
    ├── MessageList  # Scrollable message history
    │   └── Real-time updates (Supabase Realtime)
    └── MessageInput # Send messages
```

### Events System
```
EventsPage
├── CreateEvent      # Modal for event creation
└── EventCard[]      # Event display
    └── RSVP buttons (going/maybe/not)
        └── Real-time attendee count
```

### Profile Management
```
ProfilePage
├── Avatar display
├── Edit form
│   ├── Display name
│   ├── Bio (500 chars)
│   └── Interests (max 5 tags)
└── Save button
```

## 🔄 Data Flow

### Authentication
```
User → SignupForm → Supabase Auth
                  → Trigger: handle_new_user()
                  → Creates profile in DB
                  → Returns JWT
                  → Stored in AuthStore (Zustand)
                  → App re-renders with user
```

### Real-time Messaging
```
User types → MessageInput → supabase.from('messages').insert()
                          → Postgres INSERT
                          → CDC (Change Data Capture)
                          → Supabase Realtime broadcast
                          → All subscribers receive event
                          → MessageList updates instantly
```

### Post Creation
```
User uploads image → CreatePost → supabase.storage.upload()
                                → Returns public URL
                                → supabase.from('posts').insert()
                                → Post appears in feed
                                → Real-time subscription updates others
```

### RSVP Flow
```
User clicks "Ik ga" → EventCard → supabase.from('rsvps').upsert()
                                → Database trigger updates count
                                → UI updates optimistically
                                → Real-time sync to other users
```

## 🎨 Styling Architecture

### Tailwind CSS Classes
- **Colors**: `neutral-*` for grays, `blue-*` for primary actions
- **Spacing**: 8px grid system (p-4, m-2, gap-3, etc.)
- **Typography**: Base 16px, responsive font sizes
- **Dark Mode**: Default theme (bg-neutral-950)

### Component Patterns
```typescript
// Consistent button style
className="px-4 py-2 bg-blue-600 hover:bg-blue-700
           text-white rounded-lg transition
           focus:outline-none focus:ring-2 focus:ring-blue-500"

// Card container
className="bg-neutral-900 rounded-xl p-4
           border border-neutral-800"

// Input field
className="w-full px-4 py-2 bg-neutral-800
           border border-neutral-700 rounded-lg
           text-white focus:ring-2 focus:ring-blue-500"
```

## 🗄️ Database Schema

### Core Tables
1. **profiles** - User information (extends auth.users)
2. **posts** - Feed content
3. **post_likes** - Like tracking (M:N)
4. **channels** - Chat groups
5. **channel_members** - Channel membership (M:N)
6. **messages** - Chat messages
7. **events** - Event listings
8. **rsvps** - Event attendance (M:N)
9. **reports** - Moderation queue

### Relationships
```
auth.users (1) ←→ (1) profiles
profiles (1) ←→ (N) posts
posts (1) ←→ (N) post_likes ←→ (N) profiles
profiles (1) ←→ (N) channel_members ←→ (N) channels
channels (1) ←→ (N) messages ←→ (N) profiles
profiles (1) ←→ (N) events
events (1) ←→ (N) rsvps ←→ (N) profiles
```

## 🔐 Security Model

### Row Level Security (RLS)
- **All tables** have RLS enabled
- Policies use `auth.uid()` for user identification
- Default: deny all access
- Explicit policies grant specific access

### Policy Examples
```sql
-- Users can only update their own profile
CREATE POLICY "Users can update own profile"
ON profiles FOR UPDATE
USING (auth.uid() = id);

-- Users can only view messages in their channels
CREATE POLICY "Users can view messages in their channels"
ON messages FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM channel_members
    WHERE channel_id = messages.channel_id
      AND user_id = auth.uid()
  )
);
```

## 📦 State Management

### Global State (Zustand)
```typescript
authStore
├── user: User | null          # Supabase auth user
├── profile: Profile | null    # Extended profile data
├── loading: boolean           # Auth loading state
└── actions
    ├── setUser()
    ├── setProfile()
    └── setLoading()
```

### Local State (React useState)
- Component-specific UI state
- Form inputs
- Loading states
- Error messages

## 🌐 API Integration

### Supabase Client
```typescript
// Read
const { data, error } = await supabase
  .from('posts')
  .select('*, profiles(*)')
  .order('created_at', { ascending: false });

// Create
const { error } = await supabase
  .from('posts')
  .insert({ content, image_url, user_id });

// Update
const { error } = await supabase
  .from('profiles')
  .update({ bio, interests })
  .eq('id', user.id);

// Delete
const { error } = await supabase
  .from('posts')
  .delete()
  .eq('id', post_id);

// Real-time subscribe
supabase
  .channel('posts_changes')
  .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'posts' },
      (payload) => handleNewPost(payload.new))
  .subscribe();
```

## 🚀 Build & Deploy

### Development
```bash
npm run dev          # Vite dev server (HMR enabled)
```

### Production
```bash
npm run build        # Vite build → dist/
npm run preview      # Test production build locally
```

### Deployment Targets
- **Vercel** (frontend) - Auto-deploy from GitHub
- **Supabase** (backend) - Managed service

## 📊 Performance Optimizations

### Code Splitting
- Automatic via Vite
- Manual chunks for vendors (react, supabase)

### Caching Strategy
- Service Worker caches static assets
- Image caching (7 days)
- API responses not cached (real-time priority)

### Real-time Only Where Needed
- Messages: ✅ Real-time
- Posts: ✅ Real-time inserts
- Likes: ❌ Optimistic UI updates
- Events: ❌ Manual refresh

## 🧪 Testing Strategy (Future)

### Unit Tests
- Utils functions
- Zod schemas
- State management

### Component Tests
- User interactions
- Form validation
- Error states

### E2E Tests
- Critical user journeys
- Auth flow
- Post → Like → Comment
- Channel → Message → Real-time

## 📱 PWA Features

### Manifest
- Name: LocalVibe
- Theme: Dark (#0a0a0a)
- Display: Standalone
- Icons: 192px, 512px

### Service Worker
- Cache-first for assets
- Network-first for API
- Offline fallback page (future)

### Install Prompt
- Shows on mobile browsers
- Add to Home Screen

## 🎯 Development Guidelines

### File Naming
- Components: PascalCase (e.g., `PostCard.tsx`)
- Utilities: camelCase (e.g., `formatDate.ts`)
- Pages: PascalCase + Page suffix (e.g., `FeedPage.tsx`)

### Component Structure
```typescript
// 1. Imports
import { useState } from 'react';
import { supabase } from '@/lib/supabase';

// 2. Types/Interfaces
interface Props { ... }

// 3. Component
export function ComponentName({ props }: Props) {
  // 4. State
  const [state, setState] = useState();

  // 5. Hooks/Effects
  useEffect(() => { ... }, []);

  // 6. Handlers
  const handleAction = () => { ... };

  // 7. Render
  return <div>...</div>;
}
```

### Code Style
- Use TypeScript strict mode
- Prefer functional components
- Use arrow functions for event handlers
- Destructure props
- Keep components < 200 lines
- Extract logic to hooks if needed

## 🔮 Future Enhancements

See `README.md` for full roadmap.

### Phase 2 (Next)
- Push notifications
- Moderation dashboard
- Profile privacy settings
- Advanced search

### Phase 3 (Future)
- Voice notes
- @Mentions
- Thread replies
- Analytics

---

**Last Updated**: 2025-01-11
