# LocalVibe Setup Guide

## Stap 1: Database Migraties (✅ Voltooid)

De database schema is al aangemaakt met alle benodigde tabellen en policies.

## Stap 2: Storage Bucket Aanmaken

Je moet een storage bucket aanmaken voor het opslaan van afbeeldingen bij posts.

### Via Supabase Dashboard:

1. Ga naar [Supabase Dashboard](https://app.supabase.com)
2. Selecteer je project: `kajoasixfuvafzdjmvei`
3. Ga naar **Storage** in het menu
4. Klik op **New bucket**
5. Vul in:
   - **Name**: `posts`
   - **Public bucket**: ✅ Aanvinken
6. Klik op **Create bucket**

### Storage Policies Toevoegen:

Ga naar de SQL Editor en voer dit uit:

```sql
-- Allow authenticated users to upload to their own folder
CREATE POLICY "Users can upload own images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'posts' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow public read access
CREATE POLICY "Public can view images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'posts');

-- Allow users to delete their own images
CREATE POLICY "Users can delete own images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'posts' AND
  (storage.foldername(name))[1] = auth.uid()::text
);
```

## Stap 3: Auth Settings (Optioneel maar aanbevolen)

Ga naar **Authentication → Settings** in je Supabase dashboard en zorg ervoor dat:

1. **Email confirmations**: UIT (voor development)
2. **Enable email provider**: AAN
3. **Site URL**: `http://localhost:5173` (voor development)
4. **Redirect URLs**: Voeg toe:
   - `http://localhost:5173/**`
   - Je productie URL (bijv. `https://jouwdomain.vercel.app/**`)

## Stap 4: Test de Applicatie

```bash
# Start development server
npm run dev
```

Open `http://localhost:5173` en test:

1. ✅ Account aanmaken (let op 13+ leeftijdsgrens)
2. ✅ Inloggen
3. ✅ Post maken met afbeelding
4. ✅ Post liken
5. ✅ Kanaal aanmaken
6. ✅ Bericht sturen (test real-time in 2 browser tabs)
7. ✅ Event aanmaken
8. ✅ RSVP op event
9. ✅ Profiel bewerken

## Stap 5: Production Deployment

### Vercel (Frontend)

1. Push je code naar GitHub
2. Ga naar [Vercel](https://vercel.com)
3. Klik **New Project**
4. Importeer je GitHub repository
5. Voeg environment variables toe:
   ```
   VITE_SUPABASE_URL=https://kajoasixfuvafzdjmvei.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```
6. Deploy!

### Update Auth Settings

Na deployment, update de **Redirect URLs** in Supabase:
- `https://jouw-app.vercel.app/**`

## Troubleshooting

### "Storage bucket not found"
- Controleer of de bucket `posts` bestaat
- Controleer of de bucket **Public** is
- Verifieer de storage policies

### "Row Level Security policy violation"
- Check of je ingelogd bent
- Controleer of de RLS policies correct zijn toegepast
- Bekijk de Supabase logs voor details

### Real-time werkt niet
- Controleer of Realtime is ingeschakeld in je Supabase project
- Check de browser console voor WebSocket errors
- Verifieer dat de policies toestaan dat je de data mag lezen

### Build errors
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
npm run build
```

## Veelgestelde Vragen

**Q: Kan ik de app ook in het Engels gebruiken?**
A: Momenteel is alleen Nederlands ondersteund. Voor internationalisatie kun je i18next toevoegen.

**Q: Hoeveel kost Supabase?**
A: De gratis tier biedt:
- 500MB database storage
- 1GB file storage
- 50K monthly active users
- 2GB bandwidth

Dit is ruim voldoende voor development en kleine productie apps.

**Q: Hoe verwijder ik test data?**
A: Via SQL Editor:
```sql
-- Voorzichtig! Dit verwijdert alle data
TRUNCATE posts, post_likes, messages, channels, channel_members, events, rsvps, reports CASCADE;
```

**Q: Kan ik video's uploaden?**
A: De huidige implementatie ondersteunt alleen afbeeldingen. Voor video's moet je:
1. De file size limit verhogen
2. Video compression toevoegen
3. Een video player component maken

**Q: Hoe schakel ik push notificaties in?**
A: Dit staat op de roadmap (Fase 2). Je hebt nodig:
1. Service Worker notifications API
2. Supabase Real-time triggers
3. User notification preferences in database

## Support

Bij problemen:
1. Check de browser console voor errors
2. Bekijk de Supabase logs
3. Open een issue op GitHub
4. Contact via [email]

## Volgende Stappen

Zie `README.md` voor:
- Feature roadmap
- Architecture overview
- Development best practices
- Contributing guidelines
