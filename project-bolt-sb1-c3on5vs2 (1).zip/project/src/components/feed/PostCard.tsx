import { useState, useEffect } from 'react';
import { Heart, MessageCircle, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Post } from '../../types/database';
import { useAuthStore } from '../../store/authStore';

interface PostCardProps {
  post: Post;
  onDelete?: () => void;
}

export function PostCard({ post, onDelete }: PostCardProps) {
  const { user } = useAuthStore();
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likes_count);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;

    const checkIfLiked = async () => {
      const { data } = await supabase
        .from('post_likes')
        .select('id')
        .eq('post_id', post.id)
        .eq('user_id', user.id)
        .maybeSingle();

      setIsLiked(!!data);
    };

    checkIfLiked();
  }, [user, post.id]);

  const handleLike = async () => {
    if (!user) return;
    setLoading(true);

    if (isLiked) {
      const { error } = await supabase
        .from('post_likes')
        .delete()
        .eq('post_id', post.id)
        .eq('user_id', user.id);

      if (!error) {
        setLikesCount((c) => c - 1);
        setIsLiked(false);
      }
    } else {
      const { error } = await supabase
        .from('post_likes')
        .insert({ post_id: post.id, user_id: user.id });

      if (!error) {
        setLikesCount((c) => c + 1);
        setIsLiked(true);
      }
    }

    setLoading(false);
  };

  const handleDelete = async () => {
    if (!user || user.id !== post.user_id) return;
    if (!confirm('Weet je zeker dat je deze post wilt verwijderen?')) return;

    const { error } = await supabase.from('posts').delete().eq('id', post.id);

    if (!error && onDelete) {
      onDelete();
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Zojuist';
    if (diffMins < 60) return `${diffMins}m geleden`;
    if (diffHours < 24) return `${diffHours}u geleden`;
    if (diffDays < 7) return `${diffDays}d geleden`;
    return date.toLocaleDateString('nl-NL');
  };

  return (
    <article className="bg-neutral-900 rounded-xl p-4 border border-neutral-800">
      <div className="flex items-start gap-3 mb-3">
        <img
          src={post.profiles?.avatar_url || `https://ui-avatars.com/api/?name=${post.profiles?.username}&background=3b82f6&color=fff`}
          alt={post.profiles?.username}
          className="w-10 h-10 rounded-full"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-medium text-white">{post.profiles?.display_name || post.profiles?.username}</p>
            <span className="text-sm text-neutral-500">@{post.profiles?.username}</span>
            <span className="text-sm text-neutral-600">·</span>
            <span className="text-sm text-neutral-500">{formatDate(post.created_at)}</span>
          </div>
        </div>
        {user?.id === post.user_id && (
          <button
            onClick={handleDelete}
            className="text-neutral-500 hover:text-red-500 transition focus:outline-none focus:ring-2 focus:ring-red-500 rounded p-1"
            aria-label="Verwijder post"
          >
            <Trash2 size={18} />
          </button>
        )}
      </div>

      {post.content && <p className="text-neutral-200 mb-3 whitespace-pre-wrap">{post.content}</p>}

      {post.image_url && (
        <img
          src={post.image_url}
          alt=""
          className="w-full rounded-lg mb-3 max-h-96 object-cover"
          loading="lazy"
        />
      )}

      <div className="flex items-center gap-6 pt-2 border-t border-neutral-800">
        <button
          onClick={handleLike}
          disabled={loading || !user}
          className={`flex items-center gap-2 transition focus:outline-none focus:ring-2 focus:ring-red-500 rounded p-1 ${
            isLiked ? 'text-red-500' : 'text-neutral-400 hover:text-red-500'
          }`}
          aria-label={isLiked ? 'Unlike post' : 'Like post'}
        >
          <Heart className={isLiked ? 'fill-current' : ''} size={20} />
          <span className="text-sm">{likesCount}</span>
        </button>

        <button
          className="flex items-center gap-2 text-neutral-400 hover:text-blue-500 transition focus:outline-none focus:ring-2 focus:ring-blue-500 rounded p-1"
          aria-label="Reageer op post"
        >
          <MessageCircle size={20} />
        </button>
      </div>
    </article>
  );
}
