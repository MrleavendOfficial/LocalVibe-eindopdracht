import { Channel } from '../../types/database';
import { Hash, Plus } from 'lucide-react';

interface ChannelListProps {
  channels: Channel[];
  selectedChannelId: string | null;
  onSelectChannel: (channelId: string) => void;
  onCreateChannel: () => void;
}

export function ChannelList({
  channels,
  selectedChannelId,
  onSelectChannel,
  onCreateChannel,
}: ChannelListProps) {
  return (
    <div className="w-64 bg-neutral-900 border-r border-neutral-800 flex flex-col">
      <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
        <h2 className="font-bold text-white">Kanalen</h2>
        <button
          onClick={onCreateChannel}
          className="text-neutral-400 hover:text-white transition focus:outline-none focus:ring-2 focus:ring-blue-500 rounded p-1"
          aria-label="Nieuw kanaal"
        >
          <Plus size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {channels.length === 0 ? (
          <p className="text-center text-neutral-500 text-sm p-4">
            Nog geen kanalen. Maak er een aan!
          </p>
        ) : (
          channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => onSelectChannel(channel.id)}
              className={`w-full text-left px-4 py-3 flex items-center gap-3 transition ${
                selectedChannelId === channel.id
                  ? 'bg-neutral-800 text-white'
                  : 'text-neutral-400 hover:bg-neutral-800/50 hover:text-white'
              }`}
            >
              {channel.avatar_url ? (
                <img src={channel.avatar_url} alt="" className="w-6 h-6 rounded" />
              ) : (
                <Hash size={20} className="flex-shrink-0" />
              )}
              <span className="truncate">{channel.name}</span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
