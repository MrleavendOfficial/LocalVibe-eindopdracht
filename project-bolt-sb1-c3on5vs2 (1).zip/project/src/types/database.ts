export interface Profile {
  id: string;
  username: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  interests: string[];
  birth_date: string;
  created_at: string;
  updated_at: string;
}

export interface Channel {
  id: string;
  name: string;
  description: string | null;
  avatar_url: string | null;
  is_dm: boolean;
  created_by: string;
  created_at: string;
}

export interface ChannelMember {
  id: string;
  channel_id: string;
  user_id: string;
  role: 'admin' | 'member';
  joined_at: string;
}

export interface Message {
  id: string;
  channel_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  is_deleted: boolean;
  profiles?: Profile;
}

export interface Post {
  id: string;
  user_id: string;
  content: string | null;
  image_url: string | null;
  likes_count: number;
  created_at: string;
  is_deleted: boolean;
  profiles?: Profile;
}

export interface PostLike {
  id: string;
  post_id: string;
  user_id: string;
  created_at: string;
}

export interface Event {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  event_date: string;
  created_by: string;
  image_url: string | null;
  max_attendees: number | null;
  created_at: string;
  profiles?: Profile;
  rsvps?: RSVP[];
}

export interface RSVP {
  id: string;
  event_id: string;
  user_id: string;
  status: 'going' | 'maybe' | 'not_going';
  created_at: string;
  profiles?: Profile;
}

export interface Report {
  id: string;
  reported_by: string;
  content_type: 'post' | 'message' | 'profile';
  content_id: string;
  reason: string;
  status: 'pending' | 'reviewed' | 'actioned';
  created_at: string;
}
