import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Channel, Message } from '../types/database';
import { useAuthStore } from '../store/authStore';
import { ChannelList } from '../components/chat/ChannelList';
import { MessageList } from '../components/chat/MessageList';
import { MessageInput } from '../components/chat/MessageInput';
import { Loader2 } from 'lucide-react';
import { mockChannels, mockMessages, mockUsers } from '../lib/mockData';

export function ChatPage() {
  const { user } = useAuthStore();
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadChannels = async () => {
      if (!user) {
        const mockChannelData = mockChannels.map((ch, index) => ({
          id: `mock-channel-${index}`,
          name: ch.name,
          description: ch.description,
          avatar_url: ch.avatar_url,
          is_dm: ch.is_dm,
          created_by: 'mock-user',
          created_at: new Date().toISOString(),
        })) as Channel[];

        setChannels(mockChannelData);
        if (mockChannelData.length > 0) {
          setSelectedChannelId(mockChannelData[0].id);
        }
        setLoading(false);
        return;
      }

      const { data: memberData } = await supabase
        .from('channel_members')
        .select('channel_id')
        .eq('user_id', user.id);

      if (memberData && memberData.length > 0) {
        const channelIds = memberData.map((m) => m.channel_id);
        const { data: channelData } = await supabase
          .from('channels')
          .select('*')
          .in('id', channelIds)
          .order('created_at', { ascending: false });

        if (channelData && channelData.length > 0) {
          setChannels(channelData);
          if (channelData.length > 0 && !selectedChannelId) {
            setSelectedChannelId(channelData[0].id);
          }
        } else {
          const mockChannelData = mockChannels.map((ch, index) => ({
            id: `mock-channel-${index}`,
            name: ch.name,
            description: ch.description,
            avatar_url: ch.avatar_url,
            is_dm: ch.is_dm,
            created_by: user.id,
            created_at: new Date().toISOString(),
          })) as Channel[];

          setChannels(mockChannelData);
          if (mockChannelData.length > 0) {
            setSelectedChannelId(mockChannelData[0].id);
          }
        }
      } else {
        const mockChannelData = mockChannels.map((ch, index) => ({
          id: `mock-channel-${index}`,
          name: ch.name,
          description: ch.description,
          avatar_url: ch.avatar_url,
          is_dm: ch.is_dm,
          created_by: user.id,
          created_at: new Date().toISOString(),
        })) as Channel[];

        setChannels(mockChannelData);
        if (mockChannelData.length > 0) {
          setSelectedChannelId(mockChannelData[0].id);
        }
      }
      setLoading(false);
    };

    loadChannels();
  }, [user]);

  useEffect(() => {
    if (!selectedChannelId) {
      setMessages([]);
      return;
    }

    const loadMessages = async () => {
      if (selectedChannelId.startsWith('mock-channel')) {
        const channelIndex = parseInt(selectedChannelId.split('-').pop() || '0');
        const mockChannel = mockChannels[channelIndex];
        const mockMessageGroup = mockMessages.find(mg => mg.channel === mockChannel?.name);

        if (mockMessageGroup) {
          const mockMessagesWithProfiles = mockMessageGroup.messages.map((msg, idx) => {
            const user = mockUsers.find(u => u.username === msg.sender) || mockUsers[0];
            return {
              id: `mock-msg-${idx}`,
              channel_id: selectedChannelId,
              sender_id: msg.sender,
              content: msg.content,
              created_at: msg.created_at,
              updated_at: msg.created_at,
              is_deleted: false,
              profiles: {
                id: msg.sender,
                username: user.username,
                display_name: user.display_name,
                avatar_url: user.avatar_url,
                bio: user.bio,
                interests: [],
                birth_date: '2000-01-01',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              }
            } as Message;
          });
          setMessages(mockMessagesWithProfiles);
        }
        return;
      }

      const { data } = await supabase
        .from('messages')
        .select('*, profiles(*)')
        .eq('channel_id', selectedChannelId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: true })
        .limit(100);

      if (data) {
        setMessages(data);
      }
    };

    loadMessages();

    const subscription = supabase
      .channel(`channel:${selectedChannelId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `channel_id=eq.${selectedChannelId}`,
        },
        async (payload) => {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', payload.new.sender_id)
            .single();

          setMessages((prev) => [...prev, { ...payload.new, profiles: profileData } as Message]);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedChannelId]);

  const handleSendMessage = async (content: string) => {
    if (!user || !selectedChannelId) return;

    await supabase.from('messages').insert({
      channel_id: selectedChannelId,
      sender_id: user.id,
      content,
    });
  };

  const handleCreateChannel = async () => {
    if (!user) return;

    const name = prompt('Naam van het kanaal:');
    if (!name || !name.trim()) return;

    const { data: channelData, error: channelError } = await supabase
      .from('channels')
      .insert({
        name: name.trim(),
        created_by: user.id,
      })
      .select()
      .single();

    if (!channelError && channelData) {
      await supabase.from('channel_members').insert({
        channel_id: channelData.id,
        user_id: user.id,
        role: 'admin',
      });

      setChannels((prev) => [channelData, ...prev]);
      setSelectedChannelId(channelData.id);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-blue-500" size={40} />
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-4rem)] bg-neutral-950">
      <ChannelList
        channels={channels}
        selectedChannelId={selectedChannelId}
        onSelectChannel={setSelectedChannelId}
        onCreateChannel={handleCreateChannel}
      />

      <div className="flex-1 flex flex-col">
        {selectedChannelId ? (
          <>
            <div className="p-4 border-b border-neutral-800">
              <h2 className="text-xl font-bold text-white">
                {channels.find((c) => c.id === selectedChannelId)?.name}
              </h2>
            </div>
            <MessageList messages={messages} />
            <MessageInput onSend={handleSendMessage} />
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-neutral-500">
            Selecteer een kanaal om te beginnen
          </div>
        )}
      </div>
    </div>
  );
}
