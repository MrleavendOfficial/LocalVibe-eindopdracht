import { Zap, MessageSquare, Calendar, Users, Heart, Shield } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-950 via-neutral-900 to-neutral-950">
      <nav className="border-b border-neutral-800 bg-neutral-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-400 rounded-xl flex items-center justify-center">
                <Zap className="text-white" size={24} />
              </div>
              <span className="text-2xl font-bold text-white">LocalVibe</span>
            </div>
            <button
              onClick={onGetStarted}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Start Nu
            </button>
          </div>
        </div>
      </nav>

      <main>
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600/10 border border-blue-600/20 rounded-full text-blue-400 text-sm mb-6">
              <Zap size={16} />
              <span>Verbind lokaal, leef sociaal</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6">
              Ontdek wat er speelt
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
                in jouw buurt
              </span>
            </h1>

            <p className="text-xl text-neutral-400 max-w-3xl mx-auto mb-10">
              LocalVibe brengt mensen samen. Chat met vrienden, deel je momenten,
              en ontdek lokale events in één platform.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={onGetStarted}
                className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white text-lg font-semibold rounded-xl transition transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-lg shadow-blue-600/50"
              >
                Gratis Beginnen
              </button>
              <button
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-neutral-800 hover:bg-neutral-700 text-white text-lg font-semibold rounded-xl transition focus:outline-none focus:ring-2 focus:ring-neutral-500"
              >
                Meer Info
              </button>
            </div>

            <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">100%</div>
                <div className="text-sm text-neutral-500">Gratis</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">13+</div>
                <div className="text-sm text-neutral-500">Leeftijd</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">Real-time</div>
                <div className="text-sm text-neutral-500">Messaging</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">PWA</div>
                <div className="text-sm text-neutral-500">App</div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-neutral-900/50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">
                Alles wat je nodig hebt
              </h2>
              <p className="text-xl text-neutral-400">
                Een compleet platform voor lokale connecties
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-blue-600/50 transition group">
                <div className="w-12 h-12 bg-blue-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-600/20 transition">
                  <MessageSquare className="text-blue-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Real-time Chat</h3>
                <p className="text-neutral-400">
                  Instant messaging in groepskanalen. Berichten verschijnen direct zonder te vernieuwen.
                </p>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-cyan-600/50 transition group">
                <div className="w-12 h-12 bg-cyan-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-cyan-600/20 transition">
                  <Heart className="text-cyan-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Social Feed</h3>
                <p className="text-neutral-400">
                  Deel posts met tekst en afbeeldingen. Like en reageer op berichten van vrienden.
                </p>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-green-600/50 transition group">
                <div className="w-12 h-12 bg-green-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-green-600/20 transition">
                  <Calendar className="text-green-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Lokale Events</h3>
                <p className="text-neutral-400">
                  Ontdek en organiseer events in je buurt. RSVP en zie wie er ook komt.
                </p>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-purple-600/50 transition group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-600/20 transition">
                  <Users className="text-purple-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Profielen</h3>
                <p className="text-neutral-400">
                  Personaliseer je profiel met bio, interesses en avatar. Laat zien wie je bent.
                </p>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-red-600/50 transition group">
                <div className="w-12 h-12 bg-red-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-red-600/20 transition">
                  <Shield className="text-red-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Veilig & Privé</h3>
                <p className="text-neutral-400">
                  Jouw data is beschermd met moderne security. 13+ leeftijdsgrens en moderatie tools.
                </p>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 hover:border-yellow-600/50 transition group">
                <div className="w-12 h-12 bg-yellow-600/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-yellow-600/20 transition">
                  <Zap className="text-yellow-400" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Snel & Modern</h3>
                <p className="text-neutral-400">
                  Lightning-fast performance. Installeerbaar als app op je telefoon via PWA.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-3xl p-12 text-center">
              <h2 className="text-4xl font-bold text-white mb-4">
                Klaar om te beginnen?
              </h2>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                Sluit je aan bij LocalVibe en ontdek wat er speelt in jouw omgeving.
                Gratis, veilig en gemaakt voor jou.
              </p>
              <button
                onClick={onGetStarted}
                className="px-10 py-4 bg-white hover:bg-neutral-100 text-blue-600 text-lg font-semibold rounded-xl transition transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-white shadow-xl"
              >
                Account Aanmaken
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-neutral-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-400 rounded-lg flex items-center justify-center">
                  <Zap className="text-white" size={18} />
                </div>
                <span className="text-xl font-bold text-white">LocalVibe</span>
              </div>
              <p className="text-sm text-neutral-500">
                Verbind met mensen in je buurt en ontdek wat er speelt.
              </p>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-3">Product</h3>
              <ul className="space-y-2 text-sm text-neutral-500">
                <li><a href="#features" className="hover:text-white transition">Features</a></li>
                <li><a href="#" className="hover:text-white transition">Roadmap</a></li>
                <li><a href="#" className="hover:text-white transition">Changelog</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-3">Support</h3>
              <ul className="space-y-2 text-sm text-neutral-500">
                <li><a href="#" className="hover:text-white transition">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
                <li><a href="#" className="hover:text-white transition">Privacy</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-3">Community</h3>
              <ul className="space-y-2 text-sm text-neutral-500">
                <li><a href="#" className="hover:text-white transition">Discord</a></li>
                <li><a href="#" className="hover:text-white transition">Twitter</a></li>
                <li><a href="#" className="hover:text-white transition">GitHub</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-neutral-800 text-center text-sm text-neutral-500">
            <p>&copy; 2025 LocalVibe. Made with ❤️ for local communities.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
