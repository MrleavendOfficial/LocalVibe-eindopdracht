import { useState, useEffect } from 'react';
import { Calendar, MapPin, Users, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Event } from '../../types/database';
import { useAuthStore } from '../../store/authStore';

interface EventCardProps {
  event: Event;
  onDelete?: () => void;
  onRSVPChange?: () => void;
}

export function EventCard({ event, onDelete, onRSVPChange }: EventCardProps) {
  const { user } = useAuthStore();
  const [rsvpStatus, setRsvpStatus] = useState<'going' | 'maybe' | 'not_going' | null>(null);
  const [attendeeCount, setAttendeeCount] = useState(
    event.rsvps?.filter((r) => r.status === 'going').length || 0
  );

  useEffect(() => {
    if (!user) return;

    const checkRSVP = async () => {
      const { data } = await supabase
        .from('rsvps')
        .select('status')
        .eq('event_id', event.id)
        .eq('user_id', user.id)
        .maybeSingle();

      if (data) {
        setRsvpStatus(data.status as 'going' | 'maybe' | 'not_going');
      }
    };

    checkRSVP();
  }, [user, event.id]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('nl-NL', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleRSVP = async (status: 'going' | 'maybe' | 'not_going') => {
    if (!user) return;

    const { error } = await supabase.from('rsvps').upsert({
      event_id: event.id,
      user_id: user.id,
      status,
    });

    if (!error) {
      const oldStatus = rsvpStatus;
      setRsvpStatus(status);

      if (oldStatus !== 'going' && status === 'going') {
        setAttendeeCount((c) => c + 1);
      } else if (oldStatus === 'going' && status !== 'going') {
        setAttendeeCount((c) => c - 1);
      }

      if (onRSVPChange) onRSVPChange();
    }
  };

  const handleDelete = async () => {
    if (!user || user.id !== event.created_by) return;
    if (!confirm('Weet je zeker dat je dit event wilt verwijderen?')) return;

    const { error } = await supabase.from('events').delete().eq('id', event.id);

    if (!error && onDelete) {
      onDelete();
    }
  };

  return (
    <article className="bg-neutral-900 rounded-xl overflow-hidden border border-neutral-800">
      {event.image_url && (
        <img src={event.image_url} alt="" className="w-full h-48 object-cover" />
      )}

      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-xl font-bold text-white">{event.title}</h3>
          {user?.id === event.created_by && (
            <button
              onClick={handleDelete}
              className="text-neutral-500 hover:text-red-500 transition focus:outline-none focus:ring-2 focus:ring-red-500 rounded p-1"
              aria-label="Verwijder event"
            >
              <Trash2 size={18} />
            </button>
          )}
        </div>

        {event.description && (
          <p className="text-neutral-300 mb-3">{event.description}</p>
        )}

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-neutral-400">
            <Calendar size={18} />
            <span className="text-sm">{formatDate(event.event_date)}</span>
          </div>

          {event.location && (
            <div className="flex items-center gap-2 text-neutral-400">
              <MapPin size={18} />
              <span className="text-sm">{event.location}</span>
            </div>
          )}

          <div className="flex items-center gap-2 text-neutral-400">
            <Users size={18} />
            <span className="text-sm">
              {attendeeCount} {attendeeCount === 1 ? 'persoon gaat' : 'personen gaan'}
              {event.max_attendees && ` (max ${event.max_attendees})`}
            </span>
          </div>
        </div>

        {user && (
          <div className="flex gap-2">
            <button
              onClick={() => handleRSVP('going')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition focus:outline-none focus:ring-2 focus:ring-green-500 ${
                rsvpStatus === 'going'
                  ? 'bg-green-600 text-white'
                  : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
              }`}
            >
              Ik ga
            </button>
            <button
              onClick={() => handleRSVP('maybe')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition focus:outline-none focus:ring-2 focus:ring-yellow-500 ${
                rsvpStatus === 'maybe'
                  ? 'bg-yellow-600 text-white'
                  : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
              }`}
            >
              Misschien
            </button>
            <button
              onClick={() => handleRSVP('not_going')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition focus:outline-none focus:ring-2 focus:ring-red-500 ${
                rsvpStatus === 'not_going'
                  ? 'bg-red-600 text-white'
                  : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
              }`}
            >
              Niet
            </button>
          </div>
        )}
      </div>
    </article>
  );
}
