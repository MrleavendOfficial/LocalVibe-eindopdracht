import { Home, MessageSquare, Calendar, User, LogOut } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface NavigationProps {
  currentPage: 'feed' | 'chat' | 'events' | 'profile';
  onNavigate: (page: 'feed' | 'chat' | 'events' | 'profile') => void;
}

export function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const handleLogout = async () => {
    if (confirm('Weet je zeker dat je wilt uitloggen?')) {
      await supabase.auth.signOut();
    }
  };

  const navItems = [
    { id: 'feed' as const, icon: Home, label: 'Feed' },
    { id: 'chat' as const, icon: MessageSquare, label: 'Chat' },
    { id: 'events' as const, icon: Calendar, label: 'Events' },
    { id: 'profile' as const, icon: User, label: 'Profiel' },
  ];

  return (
    <nav className="bg-neutral-900 border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">L</span>
            </div>
            <span className="text-white font-bold text-xl">LocalVibe</span>
          </div>

          <div className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  currentPage === item.id
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
                }`}
                aria-label={item.label}
              >
                <item.icon size={20} />
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            ))}

            <button
              onClick={handleLogout}
              className="ml-2 flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-neutral-400 hover:text-red-500 hover:bg-neutral-800/50 transition focus:outline-none focus:ring-2 focus:ring-red-500"
              aria-label="Uitloggen"
            >
              <LogOut size={20} />
              <span className="hidden sm:inline">Uitloggen</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
