import { useState } from 'react';
import { Image, Loader2, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';

interface CreatePostProps {
  onPostCreated: () => void;
}

export function CreatePost({ onPostCreated }: CreatePostProps) {
  const { user } = useAuthStore();
  const [content, setContent] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError('Afbeelding mag maximaal 5MB zijn');
      return;
    }

    if (!file.type.startsWith('image/')) {
      setError('Alleen afbeeldingen zijn toegestaan');
      return;
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
    setError('');
  };

  const handleRemoveImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || (!content.trim() && !imageFile)) return;

    setLoading(true);
    setError('');

    let imageUrl = null;

    if (imageFile) {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('posts')
        .upload(fileName, imageFile);

      if (uploadError) {
        setError('Fout bij uploaden van afbeelding');
        setLoading(false);
        return;
      }

      const { data: { publicUrl } } = supabase.storage.from('posts').getPublicUrl(uploadData.path);
      imageUrl = publicUrl;
    }

    const { error: insertError } = await supabase.from('posts').insert({
      user_id: user.id,
      content: content.trim() || null,
      image_url: imageUrl,
    });

    if (insertError) {
      setError('Fout bij plaatsen van post');
      setLoading(false);
      return;
    }

    setContent('');
    setImageFile(null);
    setImagePreview(null);
    setLoading(false);
    onPostCreated();
  };

  return (
    <form onSubmit={handleSubmit} className="bg-neutral-900 rounded-xl p-4 border border-neutral-800">
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Wat gebeurt er?"
        rows={3}
        maxLength={500}
        className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-4 py-2 text-white placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
      />

      {imagePreview && (
        <div className="relative mt-3">
          <img src={imagePreview} alt="Preview" className="w-full rounded-lg max-h-64 object-cover" />
          <button
            type="button"
            onClick={handleRemoveImage}
            className="absolute top-2 right-2 bg-neutral-900/80 hover:bg-neutral-900 text-white rounded-full p-1 transition"
            aria-label="Verwijder afbeelding"
          >
            <X size={20} />
          </button>
        </div>
      )}

      {error && <p className="text-sm text-red-400 mt-2">{error}</p>}

      <div className="flex items-center justify-between mt-3">
        <label className="cursor-pointer text-blue-500 hover:text-blue-400 transition focus-within:ring-2 focus-within:ring-blue-500 rounded p-1">
          <Image size={20} />
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
        </label>

        <div className="flex items-center gap-3">
          <span className="text-sm text-neutral-500">{content.length}/500</span>
          <button
            type="submit"
            disabled={loading || (!content.trim() && !imageFile)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-700 disabled:text-neutral-500 text-white font-medium rounded-lg transition focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-2"
          >
            {loading && <Loader2 className="animate-spin" size={16} />}
            Plaatsen
          </button>
        </div>
      </div>
    </form>
  );
}
