import { supabase } from './supabase';
import { mockUsers, mockPosts, mockChannels, mockMessages, mockEvents } from './mockData';

const SEED_FLAG_KEY = 'localvibe_seeded';

export async function seedDatabase() {
  const hasSeeded = localStorage.getItem(SEED_FLAG_KEY);
  if (hasSeeded === 'true') {
    console.log('Database already seeded, skipping...');
    return;
  }

  try {
    console.log('Starting database seed...');

    const createdUserIds: Record<string, string> = {};

    for (const mockUser of mockUsers) {
      const tempPassword = 'TempPass123!';
      const tempEmail = `${mockUser.username}@localvibe.demo`;

      const { data: authData, error: signupError } = await supabase.auth.signUp({
        email: tempEmail,
        password: tempPassword,
        options: {
          data: {
            username: mockUser.username,
            display_name: mockUser.display_name,
            birth_date: '2000-01-01',
          },
        },
      });

      if (signupError && !signupError.message.includes('already registered')) {
        console.error(`Error creating user ${mockUser.username}:`, signupError);
        continue;
      }

      const userId = authData?.user?.id;
      if (userId) {
        createdUserIds[mockUser.username] = userId;

        await supabase
          .from('profiles')
          .update({
            display_name: mockUser.display_name,
            avatar_url: mockUser.avatar_url,
            bio: mockUser.bio,
          })
          .eq('id', userId);
      }
    }

    console.log('Mock users created:', Object.keys(createdUserIds).length);

    for (const mockPost of mockPosts) {
      const userId = createdUserIds[mockPost.username];
      if (!userId) continue;

      await supabase.from('posts').insert({
        user_id: userId,
        content: mockPost.content,
        image_url: mockPost.image_url,
        likes_count: mockPost.likes_count,
        created_at: mockPost.created_at,
      });
    }

    console.log('Mock posts created:', mockPosts.length);

    const createdChannelIds: Record<string, string> = {};
    for (const mockChannel of mockChannels) {
      const firstUserId = Object.values(createdUserIds)[0];
      const { data: channelData } = await supabase
        .from('channels')
        .insert({
          name: mockChannel.name,
          description: mockChannel.description,
          avatar_url: mockChannel.avatar_url,
          is_dm: mockChannel.is_dm,
          created_by: firstUserId,
        })
        .select()
        .single();

      if (channelData) {
        createdChannelIds[mockChannel.name] = channelData.id;

        for (const userId of Object.values(createdUserIds)) {
          await supabase.from('channel_members').insert({
            channel_id: channelData.id,
            user_id: userId,
            role: userId === firstUserId ? 'admin' : 'member',
          });
        }
      }
    }

    console.log('Mock channels created:', Object.keys(createdChannelIds).length);

    for (const mockMessageGroup of mockMessages) {
      const channelId = createdChannelIds[mockMessageGroup.channel];
      if (!channelId) continue;

      for (const message of mockMessageGroup.messages) {
        const senderId = createdUserIds[message.sender];
        if (!senderId) continue;

        await supabase.from('messages').insert({
          channel_id: channelId,
          sender_id: senderId,
          content: message.content,
          created_at: message.created_at,
        });
      }
    }

    console.log('Mock messages created');

    for (const mockEvent of mockEvents) {
      const creatorId = createdUserIds[mockEvent.created_by];
      if (!creatorId) continue;

      const { data: eventData } = await supabase
        .from('events')
        .insert({
          title: mockEvent.title,
          description: mockEvent.description,
          location: mockEvent.location,
          event_date: mockEvent.event_date,
          created_by: creatorId,
          image_url: mockEvent.image_url,
          max_attendees: mockEvent.max_attendees,
        })
        .select()
        .single();

      if (eventData) {
        const userIds = Object.values(createdUserIds);
        const goingCount = Math.min(mockEvent.going_count, userIds.length);

        for (let i = 0; i < goingCount; i++) {
          await supabase.from('rsvps').insert({
            event_id: eventData.id,
            user_id: userIds[i],
            status: i < goingCount * 0.8 ? 'going' : 'maybe',
          });
        }
      }
    }

    console.log('Mock events created:', mockEvents.length);

    localStorage.setItem(SEED_FLAG_KEY, 'true');
    console.log('Database seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

export function resetSeedFlag() {
  localStorage.removeItem(SEED_FLAG_KEY);
  console.log('Seed flag reset. Run seedDatabase() to seed again.');
}
