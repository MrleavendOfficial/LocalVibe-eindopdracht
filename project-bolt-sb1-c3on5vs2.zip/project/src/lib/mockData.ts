export const mockUsers = [
  {
    username: 'emma_hdberg',
    display_name: 'Emma van Dam',
    avatar_url: 'https://ui-avatars.com/api/?name=Emma+van+Dam&background=3b82f6&color=fff',
    bio: 'Hardenberg local 🌳 Koffie lover ☕',
  },
  {
    username: 'lucas_045',
    display_name: 'Lucas Jansen',
    avatar_url: 'https://ui-avatars.com/api/?name=Lucas+Jansen&background=10b981&color=fff',
    bio: 'Sportschool addict 💪 Avonturier',
  },
  {
    username: 'sophie_vechtdal',
    display_name: 'Sophie Bakker',
    avatar_url: 'https://ui-avatars.com/api/?name=Sophie+Bakker&background=f59e0b&color=fff',
    bio: 'Fotografie 📸 | Natuur liefhebber',
  },
  {
    username: 'daan_overijssel',
    display_name: 'Daan de Vries',
    avatar_url: 'https://ui-avatars.com/api/?name=Daan+de+Vries&background=8b5cf6&color=fff',
    bio: 'Muziek maken 🎵 DJ @ weekenden',
  },
  {
    username: 'lisa_hardenberg',
    display_name: 'Lisa Visser',
    avatar_url: 'https://ui-avatars.com/api/?name=Lisa+Visser&background=ec4899&color=fff',
    bio: 'Kunst & Design student 🎨',
  },
];

export const mockPosts = [
  {
    username: 'emma_hdberg',
    content: 'Net een heerlijke wandeling gemaakt door het Vechtdal! 🌲 Het weer is echt perfect vandaag. Wie kent nog leuke routes?',
    image_url: null,
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    likes_count: 12,
  },
  {
    username: 'lucas_045',
    content: 'Iemand zin om morgenochtend te sporten bij Sportcentrum Hardenberg? 💪',
    image_url: null,
    created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    likes_count: 8,
  },
  {
    username: 'sophie_vechtdal',
    content: 'Zonsondergang bij De Slagen was vandaag echt magisch! 🌅 Ben blij dat ik m\'n camera meenam.',
    image_url: 'https://images.pexels.com/photos/1525041/pexels-photo-1525041.jpeg?auto=compress&cs=tinysrgb&w=800',
    created_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    likes_count: 24,
  },
  {
    username: 'daan_overijssel',
    content: 'Vanavond draaien bij Grand Café in centrum! Kom je ook? 🎵🎧',
    image_url: null,
    created_at: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    likes_count: 15,
  },
  {
    username: 'lisa_hardenberg',
    content: 'Nieuwe street art ontdekt bij het station! Hardenberg wordt steeds creatiever 🎨✨',
    image_url: 'https://images.pexels.com/photos/1839919/pexels-photo-1839919.jpeg?auto=compress&cs=tinysrgb&w=800',
    created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    likes_count: 19,
  },
  {
    username: 'emma_hdberg',
    content: 'Beste koffie van Hardenberg? Ik stem voor Bakker Bart 😋☕ Wat is jullie favoriet?',
    image_url: null,
    created_at: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
    likes_count: 31,
  },
  {
    username: 'lucas_045',
    content: 'Wie gaat er volgende week naar de markt? Altijd leuk om mensen te zien!',
    image_url: null,
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    likes_count: 7,
  },
  {
    username: 'sophie_vechtdal',
    content: 'De bibliotheek heeft echt een mooi nieuw plekje gekregen. Perfect om te studeren! 📚',
    image_url: null,
    created_at: new Date(Date.now() - 36 * 60 * 60 * 1000).toISOString(),
    likes_count: 14,
  },
];

export const mockChannels = [
  {
    name: 'Hardenberg Centrum',
    description: 'Alles over het centrum van Hardenberg',
    avatar_url: null,
    is_dm: false,
  },
  {
    name: 'Sport & Fitness',
    description: 'Samen sporten en fit blijven',
    avatar_url: null,
    is_dm: false,
  },
  {
    name: 'Uitgaan Overijssel',
    description: 'Feestjes, events, en uitgaan',
    avatar_url: null,
    is_dm: false,
  },
  {
    name: 'Fotografie Vechtdal',
    description: 'Deel je mooiste foto\'s van de omgeving',
    avatar_url: null,
    is_dm: false,
  },
];

export const mockMessages = [
  {
    channel: 'Hardenberg Centrum',
    messages: [
      {
        sender: 'emma_hdberg',
        content: 'Hé iedereen! Kent iemand een goede kapper in het centrum?',
        created_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lisa_hardenberg',
        content: 'Ja! Kapsalon Style bij de Marktstraat is echt top! 💇',
        created_at: new Date(Date.now() - 2.5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lucas_045',
        content: 'En ze zijn niet eens duur. Aanrader!',
        created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'emma_hdberg',
        content: 'Thanks! Ga ik deze week langs 😊',
        created_at: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'sophie_vechtdal',
        content: 'Weet iemand of de winkels morgen open zijn?',
        created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'daan_overijssel',
        content: 'Ja, gewoon normale openingstijden!',
        created_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      },
    ],
  },
  {
    channel: 'Sport & Fitness',
    messages: [
      {
        sender: 'lucas_045',
        content: 'Morgenochtend 8 uur bootcamp bij het sportpark. Wie doet er mee? 💪',
        created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'emma_hdberg',
        content: 'Ik ben erbij! Wordt het zwaar? 😅',
        created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lucas_045',
        content: 'Haha, beetje wel maar het is de moeite waard!',
        created_at: new Date(Date.now() - 3.5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'daan_overijssel',
        content: 'Ik kan helaas niet, moet werken. Volgende keer!',
        created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
    ],
  },
  {
    channel: 'Uitgaan Overijssel',
    messages: [
      {
        sender: 'daan_overijssel',
        content: 'Dit weekend special night bij The Baron! 🎉',
        created_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lisa_hardenberg',
        content: 'Oh nice! Hoe laat begint het?',
        created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'daan_overijssel',
        content: 'Vanaf 22:00! Ik draai vanaf 23:00',
        created_at: new Date(Date.now() - 4.5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'sophie_vechtdal',
        content: 'Sounds good! Ben er waarschijnlijk ook',
        created_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lucas_045',
        content: 'Ik breng wat vrienden mee! 🔥',
        created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
    ],
  },
  {
    channel: 'Fotografie Vechtdal',
    messages: [
      {
        sender: 'sophie_vechtdal',
        content: 'Wie wil er aanstaande zondag een fotowandeling doen?',
        created_at: new Date(Date.now() - 7 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'emma_hdberg',
        content: 'Lijkt me leuk! Waar gaan we heen?',
        created_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'sophie_vechtdal',
        content: 'Dacht aan de natuurgebieden bij Diffelen. Super mooi daar!',
        created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
      },
      {
        sender: 'lisa_hardenberg',
        content: 'Ik doe ook mee! 📸',
        created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      },
    ],
  },
];

export const mockEvents = [
  {
    title: 'Weekmarkt Hardenberg',
    description: 'Wekelijkse markt in het centrum met verse producten, kleding en meer!',
    location: 'Marktplein, Hardenberg',
    event_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'emma_hdberg',
    image_url: 'https://images.pexels.com/photos/264636/pexels-photo-264636.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: null,
    going_count: 15,
  },
  {
    title: 'Live Muziek @ Grand Café',
    description: 'DJ Daan draait de beste tracks! Kom gezellig langs voor een drankje en goede vibes 🎵',
    location: 'Grand Café, Stationsweg 12',
    event_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'daan_overijssel',
    image_url: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: 50,
    going_count: 23,
  },
  {
    title: 'Bootcamp in het Park',
    description: 'Gratis outdoor training voor iedereen! Neem je sportkleding en drinkfles mee. Geschikt voor alle niveaus 💪',
    location: 'Sportpark De Boshoek',
    event_date: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'lucas_045',
    image_url: 'https://images.pexels.com/photos/4162449/pexels-photo-4162449.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: 20,
    going_count: 12,
  },
  {
    title: 'Fotowandeling Vechtdal',
    description: 'Samen op pad om de mooiste plekjes van het Vechtdal vast te leggen. Breng je camera mee! 📸',
    location: 'Natuurgebied Diffelen (verzamelen bij parkeerplaats)',
    event_date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'sophie_vechtdal',
    image_url: 'https://images.pexels.com/photos/842711/pexels-photo-842711.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: 15,
    going_count: 8,
  },
  {
    title: 'Kunstmarkt Hardenberg',
    description: 'Lokale kunstenaars presenteren hun werk. Van schilderijen tot sculpturen. Gratis entree!',
    location: 'Cultureel Centrum, Hardenberg',
    event_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'lisa_hardenberg',
    image_url: 'https://images.pexels.com/photos/1839919/pexels-photo-1839919.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: null,
    going_count: 18,
  },
  {
    title: 'Voetbaltoernooi voor Iedereen',
    description: 'Friendly voetbaltoernooi op het sportpark. Teams van 5 personen, kom je team aanmelden!',
    location: 'Sportpark De Boshoek',
    event_date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'lucas_045',
    image_url: 'https://images.pexels.com/photos/274422/pexels-photo-274422.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: 40,
    going_count: 28,
  },
  {
    title: 'Gezellige BBQ @ Het Stadspark',
    description: 'Lekker BBQ-en met de LocalVibe community! Neem je eigen vlees/groente mee, wij zorgen voor de grills en muziek 🍖',
    location: 'Stadspark Hardenberg (bij de vijver)',
    event_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    created_by: 'emma_hdberg',
    image_url: 'https://images.pexels.com/photos/1260968/pexels-photo-1260968.jpeg?auto=compress&cs=tinysrgb&w=800',
    max_attendees: 30,
    going_count: 21,
  },
];
