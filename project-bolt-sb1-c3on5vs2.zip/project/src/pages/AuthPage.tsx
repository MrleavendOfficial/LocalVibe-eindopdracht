import { useState } from 'react';
import { LoginForm } from '../components/auth/LoginForm';
import { SignupForm } from '../components/auth/SignupForm';
import { Zap, ArrowLeft } from 'lucide-react';

interface AuthPageProps {
  onSuccess: () => void;
  onBack?: () => void;
}

export function AuthPage({ onSuccess, onBack }: AuthPageProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  return (
    <div className="min-h-screen bg-neutral-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {onBack && (
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-neutral-400 hover:text-white transition mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded p-1"
          >
            <ArrowLeft size={20} />
            <span>Terug naar home</span>
          </button>
        )}

        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Zap className="text-blue-500" size={40} />
            <h1 className="text-4xl font-bold text-white">LocalVibe</h1>
          </div>
          <p className="text-neutral-400">Verbind met mensen in je buurt</p>
        </div>

        <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
          {mode === 'login' ? (
            <LoginForm onSuccess={onSuccess} onSwitchToSignup={() => setMode('signup')} />
          ) : (
            <SignupForm onSuccess={onSuccess} onSwitchToLogin={() => setMode('login')} />
          )}
        </div>
      </div>
    </div>
  );
}
