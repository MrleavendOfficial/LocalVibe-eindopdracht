import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Event } from '../types/database';
import { EventCard } from '../components/events/EventCard';
import { CreateEvent } from '../components/events/CreateEvent';
import { Plus, Loader2 } from 'lucide-react';
import { mockEvents, mockUsers } from '../lib/mockData';

export function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const loadEvents = async () => {
    const { data, error } = await supabase
      .from('events')
      .select('*, profiles(*), rsvps(id, status, user_id, profiles(*))')
      .gte('event_date', new Date().toISOString())
      .order('event_date', { ascending: true })
      .limit(50);

    if (!error && data && data.length > 0) {
      setEvents(data);
    } else {
      const mockEventsWithProfiles = mockEvents.map((event, index) => {
        const creator = mockUsers.find(u => u.username === event.created_by) || mockUsers[0];

        const rsvps = Array.from({ length: event.going_count }, (_, i) => {
          const user = mockUsers[i % mockUsers.length];
          return {
            id: `mock-rsvp-${index}-${i}`,
            event_id: `mock-event-${index}`,
            user_id: user.username,
            status: i < event.going_count * 0.8 ? 'going' : 'maybe',
            created_at: new Date().toISOString(),
            profiles: {
              id: user.username,
              username: user.username,
              display_name: user.display_name,
              avatar_url: user.avatar_url,
              bio: user.bio,
              interests: [],
              birth_date: '2000-01-01',
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            }
          };
        });

        return {
          id: `mock-event-${index}`,
          title: event.title,
          description: event.description,
          location: event.location,
          event_date: event.event_date,
          created_by: event.created_by,
          image_url: event.image_url,
          max_attendees: event.max_attendees,
          created_at: new Date().toISOString(),
          profiles: {
            id: creator.username,
            username: creator.username,
            display_name: creator.display_name,
            avatar_url: creator.avatar_url,
            bio: creator.bio,
            interests: [],
            birth_date: '2000-01-01',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          rsvps: rsvps as any,
        } as Event;
      });
      setEvents(mockEventsWithProfiles);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadEvents();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-blue-500" size={40} />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-white">Events</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-2"
        >
          <Plus size={20} />
          Nieuw Event
        </button>
      </div>

      {events.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-neutral-400">Nog geen events. Maak de eerste aan!</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {events.map((event) => (
            <EventCard key={event.id} event={event} onDelete={loadEvents} onRSVPChange={loadEvents} />
          ))}
        </div>
      )}

      {showCreateModal && (
        <CreateEvent onClose={() => setShowCreateModal(false)} onEventCreated={loadEvents} />
      )}
    </div>
  );
}
