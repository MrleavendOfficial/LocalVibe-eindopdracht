import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Post } from '../types/database';
import { CreatePost } from '../components/feed/CreatePost';
import { PostCard } from '../components/feed/PostCard';
import { Loader2 } from 'lucide-react';
import { mockPosts, mockUsers } from '../lib/mockData';

export function FeedPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  const loadPosts = async () => {
    const { data, error } = await supabase
      .from('posts')
      .select('*, profiles(*)')
      .eq('is_deleted', false)
      .order('created_at', { ascending: false })
      .limit(50);

    if (!error && data && data.length > 0) {
      setPosts(data);
    } else {
      const mockPostsWithProfiles = mockPosts.map((post, index) => {
        const user = mockUsers.find(u => u.username === post.username) || mockUsers[0];
        return {
          id: `mock-${index}`,
          user_id: post.username,
          content: post.content,
          image_url: post.image_url,
          likes_count: post.likes_count,
          created_at: post.created_at,
          is_deleted: false,
          profiles: {
            id: post.username,
            username: user.username,
            display_name: user.display_name,
            avatar_url: user.avatar_url,
            bio: user.bio,
            interests: [],
            birth_date: '2000-01-01',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }
        } as Post;
      });
      setPosts(mockPostsWithProfiles);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadPosts();

    const subscription = supabase
      .channel('posts_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'posts',
        },
        () => {
          loadPosts();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-blue-500" size={40} />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <CreatePost onPostCreated={loadPosts} />

      {posts.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-neutral-400">Nog geen posts. Wees de eerste!</p>
        </div>
      ) : (
        posts.map((post) => (
          <PostCard key={post.id} post={post} onDelete={loadPosts} />
        ))
      )}
    </div>
  );
}
