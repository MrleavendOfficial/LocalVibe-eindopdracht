import { useState } from 'react';
import { AuthProvider } from './components/auth/AuthProvider';
import { Navigation } from './components/layout/Navigation';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { FeedPage } from './pages/FeedPage';
import { ChatPage } from './pages/ChatPage';
import { EventsPage } from './pages/EventsPage';
import { ProfilePage } from './pages/ProfilePage';
import { useAuthStore } from './store/authStore';
import { Loader2 } from 'lucide-react';

type Page = 'feed' | 'chat' | 'events' | 'profile';

function AppContent() {
  const { user, loading } = useAuthStore();
  const [currentPage, setCurrentPage] = useState<Page>('feed');
  const [showAuth, setShowAuth] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center">
        <Loader2 className="animate-spin text-blue-500" size={48} />
      </div>
    );
  }

  if (!user) {
    if (showAuth) {
      return (
        <AuthPage
          onSuccess={() => setCurrentPage('feed')}
          onBack={() => setShowAuth(false)}
        />
      );
    }
    return <LandingPage onGetStarted={() => setShowAuth(true)} />;
  }

  return (
    <div className="min-h-screen bg-neutral-950">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="p-4">
        {currentPage === 'feed' && <FeedPage />}
        {currentPage === 'chat' && <ChatPage />}
        {currentPage === 'events' && <EventsPage />}
        {currentPage === 'profile' && <ProfilePage />}
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
