# LocalVibe

Een moderne sociale webapp voor lokale verbindingen, gebouwd met React, TypeScript en Supabase.

## Features

- **Landing Page**: Aantrekkelijke homepage met feature highlights en call-to-actions
- **Authentication**: Veilige signup/login met email en wachtwoord
- **Feed**: Plaats posts met tekst en afbeeldingen, like en reageer
- **Chat**: Real-time messaging in groepskanalen
- **Events**: Maak en beheer lokale events met RSVP functionaliteit
- **Profiel**: Personaliseer je profiel met bio en interesses
- **PWA**: Installeerbaar als app op mobiele apparaten
- **Dark Mode**: Standaard donker thema voor betere UX

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage, Realtime)
- **State Management**: Zustand
- **Icons**: Lucide React
- **Build Tool**: Vite
- **PWA**: vite-plugin-pwa

## Vereisten

- Node.js 18+
- npm of yarn
- Supabase account (gratis tier beschikbaar)

## Setup

### 1. Clone en installeer

```bash
git clone <repository-url>
cd localvibe
npm install
```

### 2. Supabase Setup

De database migraties zijn al toegepast. Je moet alleen de storage bucket aanmaken:

1. Ga naar je Supabase dashboard
2. Navigeer naar Storage
3. Maak een nieuwe bucket aan genaamd `posts`
4. Zet de bucket op **Public**
5. Voeg deze RLS policy toe:

```sql
-- Allow authenticated users to upload to their own folder
CREATE POLICY "Users can upload own images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'posts' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow public read access
CREATE POLICY "Public can view images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'posts');
```

### 3. Environment Variables

De `.env` file is al geconfigureerd met je Supabase credentials.

### 4. Start Development Server

```bash
npm run dev
```

De app draait nu op `http://localhost:5173`

## Mock Data (Demo Content)

De app toont automatisch demo content wanneer de database nog leeg is:

- **5 mock gebruikers** uit Hardenberg (Emma, Lucas, Sophie, Daan, Lisa)
- **8 posts** over lokale activiteiten in Hardenberg
- **4 groepskanalen** (Hardenberg Centrum, Sport & Fitness, Uitgaan, Fotografie)
- **20+ berichten** in alle kanalen met realistische gesprekken
- **7 events** in de omgeving (markt, bootcamp, muziek, fotowandeling, etc.)

Alle content is gericht op Hardenberg en het Vechtdal. De mock data wordt direct in de UI getoond zodra je inlogt, zonder database setup nodig te hebben. Perfect voor demo's en testen!

## Database Schema

Het platform heeft de volgende tabellen:

- **profiles**: User profielen met username, avatar, bio, interesses
- **channels**: Groepskanalen voor chat
- **channel_members**: Many-to-many relatie voor channel membership
- **messages**: Chat berichten met real-time updates
- **posts**: Feed posts met tekst/afbeeldingen
- **post_likes**: Likes op posts
- **events**: Event listings met datum/locatie
- **rsvps**: Event attendance tracking
- **reports**: Content moderatie systeem

## Features Detail

### Authentication (13+ leeftijdsgrens)
- Email/password signup met validatie
- Auto-profile creation bij signup
- Session management met Supabase Auth
- Secure logout

### Feed
- Plaats posts (max 500 tekens)
- Upload afbeeldingen (max 5MB)
- Like posts (real-time counter)
- View feed gesorteerd op recency
- Delete eigen posts

### Chat
- Maak groepskanalen aan
- Real-time messaging (Supabase Realtime)
- Join/leave kanalen
- Channel admin functies
- Message history (laatste 100 berichten)

### Events
- Maak events aan met titel, beschrijving, locatie, datum
- RSVP met 3 opties: Ik ga / Misschien / Niet
- Live attendee counter
- Max attendees limiet (optioneel)
- Filter events (alleen toekomstige)

### Profiel
- Edit display name, bio, interesses
- Upload avatar (toekomstig feature)
- View eigen posts
- Account instellingen

## PWA Features

De app is geoptimaliseerd als Progressive Web App:

- Installeerbaar op mobiele apparaten
- Offline caching van statische assets
- Image caching (7 dagen)
- Auto-update van service worker
- Optimized manifest voor app store

## Security

- Row Level Security (RLS) op alle tabellen
- JWT-based authenticatie
- Rate limiting (via Supabase)
- Input validatie (client + server)
- XSS bescherming
- CSRF bescherming via SameSite cookies

## Performance

- Bundle size: ~90KB gzipped
- Code splitting voor optimale load times
- Image lazy loading
- Real-time updates alleen waar nodig
- Optimized re-renders met Zustand

## Development Scripts

```bash
npm run dev          # Start dev server
npm run build        # Build voor productie
npm run preview      # Preview production build
npm run lint         # Run ESLint
npm run typecheck    # TypeScript type checking
```

## Deployment

### Vercel (Frontend)

1. Push code naar GitHub
2. Importeer project in Vercel
3. Voeg environment variables toe:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy!

### Supabase (Backend)

Backend is al live via Supabase. Geen extra deployment nodig.

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- iOS Safari 14+
- Android Chrome 90+

## Toekomstige Features (Roadmap)

### Fase 2 (Polish)
- Push notificaties
- Moderatie dashboard
- Profiel privacy instellingen
- Channel discovery/search
- Dark/light mode toggle

### Fase 3 (Stretch)
- Voice notes
- @mentions in berichten
- Thread replies op posts
- Event reminders
- Analytics dashboard
- Data export (GDPR)

## Licentie

MIT

## Support

Voor vragen of issues, maak een GitHub issue aan of neem contact op via [email].
