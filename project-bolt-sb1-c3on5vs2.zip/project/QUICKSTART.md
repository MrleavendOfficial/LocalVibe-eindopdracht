# LocalVibe - Quick Start

## 🚀 Direct Beginnen

```bash
# 1. Installeer dependencies
npm install

# 2. Start development server
npm run dev
```

Open `http://localhost:5173` in je browser.

## ⚠️ Belangrijk: Storage Bucket Setup

**Voor het uploaden van afbeeldingen werkt:**

1. Ga naar [Supabase Dashboard](https://app.supabase.com/project/kajoasixfuvafzdjmvei/storage/buckets)
2. Klik **New bucket**
3. Name: `posts`, Public: ✅
4. Ga naar **Policies** tab van de bucket
5. Voeg deze policies toe via SQL Editor:

```sql
CREATE POLICY "Users can upload own images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'posts' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Public can view images"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'posts');
```

## 📱 Test Flow

1. **Registreer** een account (13+ jaar)
2. **Maak een post** met tekst en afbeelding
3. **Like** de post
4. **Maak een kanaal** aan
5. **Stuur berichten** (test real-time in 2 tabs)
6. **Maak een event** aan
7. **RSVP** op het event
8. **Edit je profiel**

## 🛠️ Development Commands

```bash
npm run dev        # Start dev server (localhost:5173)
npm run build      # Build voor productie
npm run preview    # Preview production build
npm run lint       # Check code kwaliteit
```

## 🔑 Environment Variables

Zijn al geconfigureerd in `.env`:
- ✅ `VITE_SUPABASE_URL`
- ✅ `VITE_SUPABASE_ANON_KEY`

## 📊 Database Schema

Alle tabellen zijn al aangemaakt:
- ✅ `profiles` - User profielen
- ✅ `posts` - Feed posts
- ✅ `post_likes` - Likes
- ✅ `channels` - Chat kanalen
- ✅ `channel_members` - Memberships
- ✅ `messages` - Chat berichten
- ✅ `events` - Events
- ✅ `rsvps` - Event attendance

## 🎨 Tech Stack

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage + Realtime)
- **State**: Zustand
- **Build**: Vite
- **PWA**: vite-plugin-pwa

## 🐛 Common Issues

**"Storage bucket not found"**
→ Maak de `posts` bucket aan (zie hierboven)

**"Auth user not found"**
→ Log uit en opnieuw in

**"RLS policy violation"**
→ Check of je ingelogd bent

**Build fails**
```bash
rm -rf node_modules
npm install
```

## 📚 Meer Info

- `SETUP.md` - Gedetailleerde setup instructies
- `README.md` - Volledige documentatie
- [Supabase Docs](https://supabase.com/docs)

## 🎯 Volgende Stappen

Na local testing:

1. Push naar GitHub
2. Deploy op Vercel
3. Update Supabase redirect URLs
4. Deel met vrienden! 🎉

---

**Vragen?** Check `SETUP.md` of open een GitHub issue.
